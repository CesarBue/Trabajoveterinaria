from kivy.app import App
from kivy.uix.label import Label
from kivy.core.window import Window

Window.clearcolor = (1, 1, 1, 1)

class PruebaApp(App):
    def build(self):
        return Label(
            text="🐾",
            font_size=100,
            color=(0, 0, 0, 1),
            font_name="assets/NotoEmoji-Regular.ttf"
        )

PruebaApp().run()