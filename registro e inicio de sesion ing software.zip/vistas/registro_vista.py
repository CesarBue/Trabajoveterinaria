import ctypes
try:
    ctypes.windll.user32.SetProcessDpiAwarenessContext(-4)
except Exception:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from configuracion.base_datos import registrar_usuario, registrar_empleado, crear_tabla_usuario, crear_tabla_empleado

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.widget import Widget
from kivy.core.window import Window

Window.clearcolor = (0.95, 0.97, 1, 1)
Window.size = (450, 700)

class RegistroApp(App):
    def build(self):
        layout = BoxLayout(orientation="vertical", padding=40, spacing=10)

        fila_titulo = BoxLayout(orientation="horizontal", size_hint_y=None, height=60, spacing=0)
        emoji_titulo = Label(
            text="🐾", font_size=32, font_name="assets/NotoEmoji-Regular.ttf",
            color=(0, 0, 0, 1), size_hint_x=None, width=35
        )
        fila_titulo.add_widget(emoji_titulo)
        texto_titulo = Label(text="Crear Cuenta", font_size=28, color=(0.13, 0.4, 0.6, 1), bold=True)
        fila_titulo.add_widget(texto_titulo)
        layout.add_widget(fila_titulo)

        layout.add_widget(Label(text="Nombre:", color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=22))
        self.campo_nombre = TextInput(multiline=False, size_hint_y=None, height=45, font_size=16, padding=[10, 12, 10, 10])
        layout.add_widget(self.campo_nombre)

        layout.add_widget(Label(text="Email:", color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=22))
        self.campo_email = TextInput(multiline=False, size_hint_y=None, height=45, font_size=16, padding=[10, 12, 10, 10])
        layout.add_widget(self.campo_email)

        layout.add_widget(Label(text="Contraseña:", color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=22))
        self.campo_contrasena = TextInput(multiline=False, password=True, size_hint_y=None, height=45, font_size=16, padding=[10, 12, 10, 10])
        layout.add_widget(self.campo_contrasena)

        # --- Tipo de perfil: Cliente / Empleado ---
        fila_cliente = BoxLayout(size_hint_y=None, height=32)
        self.check_cliente = CheckBox(group="tipo_perfil", active=True, size_hint_x=None, width=40)
        self.check_cliente.bind(active=self.actualizar_visibilidad_empleado)
        fila_cliente.add_widget(self.check_cliente)
        fila_cliente.add_widget(Label(text="Cliente", color=(0.2, 0.2, 0.2, 1)))
        layout.add_widget(fila_cliente)

        fila_empleado = BoxLayout(size_hint_y=None, height=32)
        self.check_empleado = CheckBox(group="tipo_perfil", size_hint_x=None, width=40)
        self.check_empleado.bind(active=self.actualizar_visibilidad_empleado)
        fila_empleado.add_widget(self.check_empleado)
        fila_empleado.add_widget(Label(text="Empleado", color=(0.2, 0.2, 0.2, 1)))
        layout.add_widget(fila_empleado)

       
        self.seccion_rol_empleado = BoxLayout(orientation="vertical", size_hint_y=None, height=246, opacity=0, disabled=True)

        self.seccion_rol_empleado.add_widget(Label(text="Rol:", color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=22))

        fila_veterinario = BoxLayout(size_hint_y=None, height=32)
        self.check_veterinario = CheckBox(group="rol_empleado", size_hint_x=None, width=40)
        self.check_veterinario.bind(active=self.actualizar_visibilidad_veterinario)
        fila_veterinario.add_widget(self.check_veterinario)
        fila_veterinario.add_widget(Label(text="Médico Veterinario", color=(0.2, 0.2, 0.2, 1)))
        self.seccion_rol_empleado.add_widget(fila_veterinario)

        fila_estilista = BoxLayout(size_hint_y=None, height=32)
        self.check_estilista = CheckBox(group="rol_empleado", size_hint_x=None, width=40)
        fila_estilista.add_widget(self.check_estilista)
        fila_estilista.add_widget(Label(text="Estilista", color=(0.2, 0.2, 0.2, 1)))
        self.seccion_rol_empleado.add_widget(fila_estilista)

        fila_cuidador = BoxLayout(size_hint_y=None, height=32)
        self.check_cuidador = CheckBox(group="rol_empleado", size_hint_x=None, width=40)
        fila_cuidador.add_widget(self.check_cuidador)
        fila_cuidador.add_widget(Label(text="Cuidador", color=(0.2, 0.2, 0.2, 1)))
        self.seccion_rol_empleado.add_widget(fila_cuidador)

        # --- Especialidad y teléfono (solo si es Médico Veterinario) ---
        self.seccion_veterinario = BoxLayout(orientation="vertical", size_hint_y=None, height=128, opacity=0, disabled=True)

        self.seccion_veterinario.add_widget(Label(text="Especialidad:", color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=22))
        self.campo_especialidad = TextInput(multiline=False, size_hint_y=None, height=42, font_size=15, padding=[10, 10, 10, 10])
        self.seccion_veterinario.add_widget(self.campo_especialidad)

        self.seccion_veterinario.add_widget(Label(text="Teléfono:", color=(0.2, 0.2, 0.2, 1), size_hint_y=None, height=22))
        self.campo_telefono = TextInput(multiline=False, size_hint_y=None, height=42, font_size=15, padding=[10, 10, 10, 10])
        self.seccion_veterinario.add_widget(self.campo_telefono)

        self.seccion_rol_empleado.add_widget(self.seccion_veterinario)
        self.mensaje = Label(text="", color=(0.8, 0.1, 0.1, 1), size_hint_y=None, height=40)
        layout.add_widget(self.mensaje)
        layout.add_widget(self.seccion_rol_empleado)

        layout.add_widget(Widget())

        boton_registrar = Button(
            text="Registrarse", background_color=(0.2, 0.6, 0.86, 1), background_normal="",
            color=(1, 1, 1, 1), size_hint_y=None, height=50, font_size=17, bold=True
        )
        boton_registrar.bind(on_press=self.registrar_usuario_click)
        layout.add_widget(boton_registrar)

        return layout

    def actualizar_visibilidad_empleado(self, instance, value):
     if self.check_empleado.active:
        self.seccion_rol_empleado.opacity = 1
        self.seccion_rol_empleado.disabled = False
     else:
        self.seccion_rol_empleado.opacity = 0
        self.seccion_rol_empleado.disabled = True

    def actualizar_visibilidad_veterinario(self, instance, value):
     if self.check_veterinario.active:
        self.seccion_veterinario.opacity = 1
        self.seccion_veterinario.disabled = False
     else:
        self.seccion_veterinario.opacity = 0
        self.seccion_veterinario.disabled = True

    def registrar_usuario_click(self, instance):
        nombre = self.campo_nombre.text
        email = self.campo_email.text
        contrasena = self.campo_contrasena.text
        tipo_perfil = "Cliente" if self.check_cliente.active else "Empleado"

        if nombre == "":
            self.mensaje.text = "El nombre es obligatorio"
            return
        if email == "":
            self.mensaje.text = "El email es obligatorio"
            return
        if "@" not in email or "." not in email:
            self.mensaje.text = "El email no tiene un formato válido"
            return
        if contrasena == "":
            self.mensaje.text = "La contraseña es obligatoria"
            return
        if len(contrasena) < 4:
            self.mensaje.text = "La contraseña debe tener al menos 4 caracteres"
            return

        if tipo_perfil == "Empleado":
            if not (self.check_veterinario.active or self.check_estilista.active or self.check_cuidador.active):
                self.mensaje.text = "Selecciona un rol de empleado"
                return

        id_usuario = registrar_usuario(nombre, email, contrasena, tipo_perfil)

        if tipo_perfil == "Empleado":
            if self.check_veterinario.active:
                rol_empleado = "Medico Veterinario"
                especialidad = self.campo_especialidad.text
                telefono = self.campo_telefono.text
            elif self.check_estilista.active:
                rol_empleado = "Estilista"
                especialidad = ""
                telefono = ""
            else:
                rol_empleado = "Cuidador"
                especialidad = ""
                telefono = ""

            registrar_empleado(id_usuario, rol_empleado, especialidad, telefono)

        self.mensaje.color = (0.1, 0.6, 0.2, 1)
        self.mensaje.text = "Usuario registrado correctamente"

crear_tabla_usuario()
crear_tabla_empleado()
RegistroApp().run()