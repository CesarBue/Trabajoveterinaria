import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from configuracion.base_datos import verificar_login

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.core.window import Window
Window.size = (450, 600)

Window.clearcolor = (0.95, 0.97, 1, 1)

class VeterinariaApp(App):
    def build(self):
        layout = BoxLayout(orientation="vertical", padding=40, spacing=0)

        fila_titulo = BoxLayout(orientation="horizontal", size_hint_y=None, height=60, spacing=0, padding=[0, 0, 0, 0])

        emoji_titulo = Label(
            text="🐾",
            font_size=32,
            font_name="assets/NotoEmoji-Regular.ttf",
            color=(0, 0, 0, 1),
            size_hint_x=None,
            width=10
        )
        fila_titulo.add_widget(emoji_titulo)

        texto_titulo = Label(
            text="Iniciar Sesión",
            font_size=28,
            color=(0.13, 0.4, 0.6, 1),
            bold=True
        )
        fila_titulo.add_widget(texto_titulo)

        layout.add_widget(fila_titulo)

        layout.add_widget(Label(text="Email:", color=(0.2, 0.2, 0.2, 1)))
        self.campo_email = TextInput(multiline=False, size_hint_y=None, height=55, font_size=18, padding=[10, 15, 10, 10])
        layout.add_widget(self.campo_email)

        layout.add_widget(Label(text="Contraseña:", color=(0.2, 0.2, 0.2, 1)))
        self.campo_contrasena = TextInput(multiline=False, password=True, size_hint_y=None, height=55, font_size=18, padding=[10, 15, 10, 10])
        layout.add_widget(self.campo_contrasena)

        self.mensaje = Label(text="", color=(0.8, 0.1, 0.1, 1))
        layout.add_widget(self.mensaje)

        boton_ingresar = Button(
            text="Ingresar",
            background_color=(0.2, 0.6, 0.86, 1),
            background_normal="",
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=50,
            font_size=17,
            bold=True
        )
        boton_ingresar.bind(on_press=self.iniciar_sesion)
        layout.add_widget(boton_ingresar)

        boton_recuperar = Button(
            text="Recuperar contraseña",
            background_color=(0.85, 0.85, 0.85, 1),
            background_normal="",
            color=(0.15, 0.15, 0.15, 1),
            size_hint_y=None,
            height=40,
            font_size=14
        )
        boton_recuperar.bind(on_press=self.recuperar_contrasena)
        layout.add_widget(boton_recuperar)
        return layout

    def iniciar_sesion(self, instance):
        email = self.campo_email.text
        contrasena = self.campo_contrasena.text

        usuario = verificar_login(email, contrasena)

        if usuario:
            self.mensaje.color = (0.1, 0.6, 0.2, 1)
            self.mensaje.text = f"Bienvenido, {usuario[1]}"
        else:
            self.mensaje.color = (0.8, 0.1, 0.1, 1)
            self.mensaje.text = "Email o contraseña incorrectos"

    def recuperar_contrasena(self, instance):
        print("Recuperar contraseña presionado")

VeterinariaApp().run()