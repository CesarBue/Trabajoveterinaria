import sqlite3
import hashlib

def conectar():
    conexion = sqlite3.connect("veterinaria.db")
    return conexion

def crear_tabla_usuario():
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuario (
            idUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            contrasena TEXT NOT NULL,
            tipoPerfil TEXT NOT NULL
        )
    """)
    conexion.commit()
    conexion.close()

def crear_tabla_mascota():
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS mascota (
            idMascota INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            tipoDeMascota TEXT NOT NULL,
            raza TEXT,
            edad INTEGER,
            peso REAL,
            observaciones TEXT,
            idUsuario INTEGER NOT NULL,
            FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario)
        )
    """)
    conexion.commit()
    conexion.close()

def crear_tabla_empleado():
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS empleado (
            idEmpleado INTEGER PRIMARY KEY AUTOINCREMENT,
            rolEmpleado TEXT NOT NULL,
            especialidad TEXT,
            telefono TEXT,
            idUsuario INTEGER NOT NULL,
            FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario)
        )
    """)
    conexion.commit()
    conexion.close()

def encriptar_contrasena(contrasena):
    return hashlib.sha256(contrasena.encode()).hexdigest()

def registrar_usuario(nombre, email, contrasena, tipo_perfil):
    contrasena_encriptada = encriptar_contrasena(contrasena)
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "INSERT INTO usuario (nombre, email, contrasena, tipoPerfil) VALUES (?, ?, ?, ?)",
        (nombre, email, contrasena_encriptada, tipo_perfil)
    )
    id_usuario = cursor.lastrowid
    conexion.commit()
    conexion.close()
    return id_usuario

def registrar_empleado(id_usuario, rol_empleado, especialidad, telefono):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "INSERT INTO empleado (rolEmpleado, especialidad, telefono, idUsuario) VALUES (?, ?, ?, ?)",
        (rol_empleado, especialidad, telefono, id_usuario)
    )
    conexion.commit()
    conexion.close()

def verificar_login(email, contrasena):
    contrasena_encriptada = encriptar_contrasena(contrasena)
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "SELECT * FROM usuario WHERE email = ? AND contrasena = ?",
        (email, contrasena_encriptada)
    )
    resultado = cursor.fetchone()
    conexion.close()
    return resultado

if __name__ == "__main__":
    crear_tabla_usuario()
    crear_tabla_mascota()
    crear_tabla_empleado()
    print("Tablas creadas correctamente")