from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput

class PruebaApp(App):
    def build(self):
        layout = BoxLayout(orientation="vertical", padding=40)
        campo = TextInput(multiline=False, password=True)
        layout.add_widget(campo)
        return layout

PruebaApp().run()